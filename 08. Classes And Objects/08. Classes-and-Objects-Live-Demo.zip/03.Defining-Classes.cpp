#include<iostream>
#include<string>
using namespace std;

class Person {
    public:
    string name;
    int age;
    double heightMeters;
};

int main() {
    Person p;
}
